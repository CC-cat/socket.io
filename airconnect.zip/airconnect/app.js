var io = require('socket.io').listen(1800);
//var currentIP="10.16.237.51";
//var currentIP = "10.16.90.93";
var recvrs = {};
var users = {};

io.sockets.on('connection', function (socket) {
    console.log("connect");


	socket.on('btn1click',function(event){
	console.log("btn msg:",event);
	//socket.emit('serverMsg',event);
	 socket.broadcast.emit('serverMsg',event);
	});
	var nickname;
	socket.on('newUser',function(data){
		 if(data in users){

		 }else{
			nickname = data;
			users[nickname]= socket;
			console.log("user is:"+nickname);

			socket.emit('open',nickname+" is connect!");//通知客户端已连接

		 }
     	//console.log("users is:"+users);
		});

	socket.on('message', function (to,msg) {
    	console.log('to is:'+to+",msg is:"+ msg);
		if(to in users){
			var eventName = "serverMsg"+to;
			console.log('to is there,'+eventName);
			users[to].emit(eventName,msg);
			//socket.broadcast.emit('message_a',msg);
			//socket.broadcast.emit(eventName,msg);

		}
	  });


	  //监听用户退出
	socket.on('disconnect', function(){

			//删除
			delete users[nickname];
			console.log('quit is:'+nickname);
			//console.log(obj.username+'退出了聊天室');

	});

	// var allowCrossDomain = function(req, res, next) {
	// 	res.header('Access-Control-Allow-Origin', '*');
	// 	res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
	// 	res.header('Access-Control-Allow-Headers', 'Content-Type');

	// 	next();
	// };
	// socket.use(allowCrossDomain);


});


